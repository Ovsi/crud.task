<?php

namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class ProductController extends Controller
{
    public function index(){
        $products = Product::all();
        return view('products.index', compact('products'));
    }

    public function create(){
        return view('products.create');
    }


    public function store(Request $request){
        $products =new Product;
        if($request->hasfile('image')){
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension();
            $filename = time(). '.' .$extension;
            $file->move('uploads/products/',$filename);
            $products->image = $filename;

        }
        
        
        $products->name = $request->input('name');
        $products->description = $request->input('description');
        $products->status = $request->input('status');
        $products->tag = $request->input('tag');

        $products->save();
        return redirect()->back()->with('status', 'Product successfully created');

    }

    public function edit($id){
        $products = Product::find($id);
        return view('products.edit', compact('products'));
    }


    public function update(Request $request, $id){
        $products = Product::find($id);
        if($request->hasfile('image')){

            $destination = 'uploads/products/'.$products->image;
            if(File::exists($destination))
            {
                File::delete($destination);

            }
            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension();
            $filename = time(). '.' .$extension;
            $file->move('uploads/products/',$filename);
            $products->image = $filename;

        }
        $products->name = $request->input('name');
        $products->description = $request->input('description');
        $products->status = $request->input('status');
        $products->tag = $request->input('tag');

        $products->update();
        return redirect()->back()->with('status', 'Product successfully updated');



    }

    public function destroy($id){
        $products = Product::find($id);
        $destination = 'uploads/products/'.$products->image;
        if(File::exists($destination))
        {
            File::delete($destination);

        }
        $products->delete();
        return redirect()->back()->with('status', 'Product successfully deleted');


    }
}



