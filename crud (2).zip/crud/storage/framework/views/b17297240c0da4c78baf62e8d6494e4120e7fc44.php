

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Products
                    <a href="<?php echo e(url('add-products')); ?>" class="btn btn-primary float-end">Create Product</a>
                    </h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>Tag</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td>
                                    <img src="<?php echo e(asset('uploads/products/'.$item->image)); ?>"  width="70px"  height="70px" alt="Image">
                                </td>

                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->description); ?></td>
                                <td><?php echo e($item->status); ?></td>
                                <td><?php echo e($item->tag); ?></td>
                                <td>
                                    <a href="<?php echo e(url('edit-products/'.$item->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                </td>
                                <td>
                                    <!-- <a href="<?php echo e(url('delete-products/'.$item->id)); ?>" class="btn btn-danger btn-sm">Delete</a>     -->

                                    <form action="<?php echo e(url('delete-products/'.$item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views/products/index.blade.php ENDPATH**/ ?>