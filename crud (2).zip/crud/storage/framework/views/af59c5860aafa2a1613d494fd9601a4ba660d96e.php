

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(session('status')): ?>
            <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4>Edit Products
                    <a href="<?php echo e(url('products')); ?>" class="btn btn-danger float-end">Back</a>
                    </h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('update-products/'.$products->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group mb-3">
                            <label for="">Image</label>
                            <input type="file" name="image" class="form-control">
                            <img src="<?php echo e(asset('uploads/products/'.$products->image)); ?>"  width="70px"  height="70px" alt="Image">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Name</label>
                            <input type="text" name="name"  value="<?php echo e($products->name); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Description</label>
                            <input type="text" name="description"  value="<?php echo e($products->description); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Status</label>
                            <input type="text" name="status"  value="<?php echo e($products->status); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Tag</label>
                            <input type="text" name="tag"  value="<?php echo e($products->tag); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">Update Product</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views/products/edit.blade.php ENDPATH**/ ?>